<?php
/**
 * Configuration for this installation. Lives in private/, inside public_html,
 * and is blocked from HTTP by that folder's .htaccess. Replace the empty SMTP
 * values with real credentials. This file is gitignored and must not be
 * committed.
 */
return [
    'smtp_host'    => 'smtp.resend.com',
    'smtp_port'    => 587,
    'smtp_secure'  => 'tls',
    'smtp_user'    => 'resend',
    'smtp_pass'    => '',

    'from_email'   => 'onboarding@resend.dev',
    'from_name'    => 'Personal Details Form',
    'to_email'     => 'delivered@resend.dev',
    'to_name'      => 'Records Team',

    'app_name'     => 'Personal Details',
    'timezone'     => 'Europe/London',
    'pdf_password' => '',
    'app_debug'    => false,
    'storage_dir'  => null,
];
